# main.py
from controller import ImageApp

def main():
    app = ImageApp()
    app.mainloop()

if __name__ == "__main__":
    main()
