from controller import ImageApp

def main():
    app = ImageApp()   # ✅ no argument
    app.mainloop()

if __name__ == "__main__":
    main()
